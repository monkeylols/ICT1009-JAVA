package JavaProj;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.util.logging.*;
import javax.sound.sampled.*;

public class Sound {// Holds one audio file

    private Clip clip;

    Sound(String filename) {
        try {
            InputStream istream = GameFrame.class.getResourceAsStream("resources/" + filename);
            AudioInputStream stream = AudioSystem.getAudioInputStream(istream);
            AudioFormat format = stream.getFormat();
            DataLine.Info info = new DataLine.Info(Clip.class, format);
            try {
                clip = (Clip) AudioSystem.getLine(info);
                clip.open(stream);
            } catch (LineUnavailableException ex) {
            }
        } catch (UnsupportedAudioFileException ex) {
        } catch (IOException ex) {
        }
    }

    public void playSound() {
        clip.start();
        clip.loop(999); // Play in a loop
    }
}
