package JavaProj;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class GameFrame extends JFrame implements ActionListener {

    private JPanel northPnl, northWestPnl, northEastPnl;
    private JButton noobBtn, expBtn, HrdcreBtn;
    
    private JPanel centerPnl, difficultyPnl, difficultyPnl2;
    private JPanel noobWestPnl, noobEastPnl;
    private JPanel expWestPnl, expEastPnl;  
    private JPanel HrdcreWestPnl, HrdcreEastPnl;
    private JButton[] noobArr, expArr, HrdcreArr;
    private JButton[] noobGameArr, expGameArr, HrdcreGameArr, 
                      selectedPuzzleArr, selectedBoardArr;
    
    private ImageIcon[] myPicArr, myPic2Arr, myPic3Arr;
    
    private ImageIcon selectedImg = null;
    private JButton selectedButton = null;
    private int buttonSelected = 0;
    private int movecount = 0;
    private int completebutton = 0;
    
    private JPanel southPnl, southWestPnl, 
                   southWest_northPnl, southWest_southPnl;
    private JPanel Instructions;
    private JPanel imagePnl, noobPicPnl, expPicPnl, HrdcrePicPnl;
    private JLabel nameLbl;
    private JTextField nameTxt;
    private JButton startBtn, histBtn, resetBtn, exitBtn;
    private JTextArea instructionTxtA;
    private JScrollPane instructionScr;
    private JLabel OrigPic;
    private String infoStr = "S/N\tPlayer Name\tNo. of Steps\n";
    private int count = 0;
    
    private void init() {
        Sound PokemonSong = new Sound("Pokemon.wav");
        PokemonSong.playSound();
    }
    
    private void initNorthPnl() {
        northPnl = new JPanel(new GridLayout(1, 2));

        northWestPnl = new JPanel();
        nameLbl = new JLabel("Alan & Wei Feng's Game");
        nameLbl.setForeground(Color.RED);
        nameLbl.setFont(new Font("Serif", Font.BOLD, 25));
        northWestPnl.add(nameLbl);

        northEastPnl = new JPanel(new GridLayout(1, 3));
        noobBtn = new JButton("Noob");
        noobBtn.addActionListener(this);

        expBtn = new JButton("Experienced");
        expBtn.addActionListener(this);

        HrdcreBtn = new JButton("Hardcore");
        HrdcreBtn.addActionListener(this);

        northEastPnl.add(noobBtn);
        northEastPnl.add(expBtn);
        northEastPnl.add(HrdcreBtn);

        northPnl.add(northWestPnl);
        northPnl.add(northEastPnl);
    }

    private void initCenterPnl() {
        centerPnl = new JPanel(new GridLayout(1, 2));

        difficultyPnl  = new JPanel(new CardLayout());
        difficultyPnl2 = new JPanel(new CardLayout());
        
        // Noob difficulty
        noobWestPnl = new JPanel(new GridLayout(3, 3));
        noobWestPnl.setBorder(BorderFactory.createTitledBorder("Puzzle Pieces"));
        noobArr = new JButton[9];
        ImageIcon myPic = new ImageIcon("pichu.jpg");
        myPic = ImageUtil.cropImage(myPic, 500, 400);
        myPicArr = ImageUtil.sliceImage(3, 3, myPic);
        ImageIcon[] shuffledArr = shuffleImages(myPicArr);
        for (int i = 0; i < noobArr.length; i++) {
            noobArr[i] = new JButton();
            noobArr[i].setIcon(shuffledArr[i]);
            noobArr[i].setPreferredSize(new Dimension(myPicArr[i].getIconWidth(), myPicArr[i].getIconHeight()));
            noobWestPnl.add(noobArr[i]);
            noobArr[i].addActionListener(this);
        }
        noobEastPnl = new JPanel(new GridLayout(3, 3));
        noobEastPnl.setBorder(BorderFactory.createTitledBorder("Game Board"));
        noobGameArr = new JButton[9];
        for (int i = 0; i < noobGameArr.length; i++) {
            noobGameArr[i] = new JButton();
            noobEastPnl.add(noobGameArr[i]);
            noobGameArr[i].addActionListener(this);
        }
        difficultyPnl .add("Noob", noobWestPnl);
        difficultyPnl2.add("Noob",noobEastPnl);
        selectedPuzzleArr = noobArr;
        selectedBoardArr = noobGameArr;

        // Experienced difficulty
        expWestPnl = new JPanel(new GridLayout(4, 4));
        expWestPnl.setBorder(BorderFactory.createTitledBorder("Puzzle Pieces"));
        expArr = new JButton[16];
        ImageIcon myPic2 = new ImageIcon("pikapika.jpg");
        myPic2 = ImageUtil.cropImage(myPic2, 500, 400);
        myPic2Arr = ImageUtil.sliceImage(4, 4, myPic2);
        ImageIcon[] shuffled2Arr = shuffleImages(myPic2Arr);
        for (int i = 0; i < expArr.length; i++) {
            expArr[i] = new JButton();
            expArr[i].setIcon(shuffled2Arr[i]);
            expArr[i].setPreferredSize(new Dimension(myPic2Arr[i].getIconWidth(), myPic2Arr[i].getIconHeight()));
            expWestPnl.add(expArr[i]);
            expArr[i].addActionListener(this);
        }
        expEastPnl = new JPanel(new GridLayout(4, 4));
        expEastPnl.setBorder(BorderFactory.createTitledBorder("Game Board"));
        expGameArr = new JButton[16];
        for (int i = 0; i < expGameArr.length; i++) {
            expGameArr[i] = new JButton();
            expEastPnl.add(expGameArr[i]);
            expGameArr[i].addActionListener(this);
        }
        difficultyPnl.add("Experienced", expWestPnl);
        difficultyPnl2.add("Experienced", expEastPnl);

        // Hardcore difficulty
        HrdcreWestPnl = new JPanel(new GridLayout(5, 5));
        HrdcreWestPnl.setBorder(BorderFactory.createTitledBorder("Puzzle Pieces"));
        HrdcreArr = new JButton[25];
        ImageIcon myPic3 = new ImageIcon("raichu.jpg");
        myPic3 = ImageUtil.cropImage(myPic3, 500, 400);
        myPic3Arr = ImageUtil.sliceImage(5, 5, myPic3);
        ImageIcon[] shuffled3Arr = shuffleImages(myPic3Arr);
        for (int i = 0; i < HrdcreArr.length; i++) {
            HrdcreArr[i] = new JButton();
            HrdcreArr[i].setIcon(shuffled3Arr[i]);
            HrdcreArr[i].setPreferredSize(new Dimension(myPic3Arr[i].getIconWidth(), myPic3Arr[i].getIconHeight()));
            HrdcreWestPnl.add(HrdcreArr[i]);
            HrdcreArr[i].addActionListener(this);
        }
        HrdcreEastPnl = new JPanel(new GridLayout(5, 5));
        HrdcreEastPnl.setBorder(BorderFactory.createTitledBorder("Game Board"));
        HrdcreGameArr = new JButton[25];
        for (int i = 0; i < HrdcreGameArr.length; i++) {
            HrdcreGameArr[i] = new JButton();
            HrdcreEastPnl.add(HrdcreGameArr[i]);
            HrdcreGameArr[i].addActionListener(this);
        }
        difficultyPnl.add("Hardcore",HrdcreWestPnl);
        difficultyPnl2.add("Hardcore", HrdcreEastPnl);

        centerPnl.add(difficultyPnl);
        centerPnl.add(difficultyPnl2);
    }

    private void initSouthPnl() {
        southPnl = new JPanel(new GridLayout(1, 2));
        southPnl.setBorder(BorderFactory.createTitledBorder("Puzzle Game"));

        southWestPnl = new JPanel(new BorderLayout());

        southWest_northPnl = new JPanel();
        nameLbl = new JLabel("Please enter your name:");
        nameTxt = new JTextField(15);
        nameTxt.addActionListener(this);
        southWest_northPnl.add(nameLbl);
        southWest_northPnl.add(nameTxt);

        southWest_southPnl = new JPanel(new GridLayout(2, 2));

        startBtn = new JButton("Start Game");
        startBtn.addActionListener(this);

        histBtn = new JButton("Get History");
        histBtn.addActionListener(this);

        resetBtn = new JButton("Reset Game");
        resetBtn.addActionListener(this);

        exitBtn = new JButton("Exit Game");
        exitBtn.addActionListener(this);

        southWest_southPnl.add(startBtn);
        southWest_southPnl.add(histBtn);
        southWest_southPnl.add(resetBtn);
        southWest_southPnl.add(exitBtn);

        southWestPnl.add(southWest_northPnl, BorderLayout.NORTH);
        southWestPnl.add(southWest_southPnl, BorderLayout.CENTER);

        Instructions = new JPanel();
        Instructions.setBorder(BorderFactory.createTitledBorder("Instructions"));
        instructionTxtA = new JTextArea(12, 27);
        instructionTxtA.setLineWrap(true);
        instructionScr = new JScrollPane(instructionTxtA,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        Instructions.add(instructionScr);

        imagePnl = new JPanel(new CardLayout());
        
        // Orig pic for noob difficulty
        noobPicPnl = new JPanel();
        noobPicPnl.setBorder(BorderFactory.createTitledBorder("Original Picture"));
        OrigPic = new JLabel();
        ImageIcon icon = new ImageIcon("pichu.jpg");
        icon = new ImageIcon(icon.getImage().getScaledInstance(200, 200, Image.SCALE_SMOOTH));
        OrigPic.setIcon(icon);
        noobPicPnl.add(OrigPic);
        imagePnl.add("OrigNoob", noobPicPnl);
        
        // Orig pic for experienced difficulty
        expPicPnl = new JPanel();
        expPicPnl.setBorder(BorderFactory.createTitledBorder("Original Picture"));
        OrigPic = new JLabel();
        ImageIcon icon2 = new ImageIcon("pikapika.jpg");
        icon2 = new ImageIcon(icon2.getImage().getScaledInstance(300, 200, Image.SCALE_SMOOTH));
        OrigPic.setIcon(icon2);
        expPicPnl.add(OrigPic);
        imagePnl.add("OrigExp", expPicPnl);
        
        // Orig pic for hardcore difficulty
        HrdcrePicPnl = new JPanel();
        HrdcrePicPnl.setBorder(BorderFactory.createTitledBorder("Original Picture"));
        OrigPic = new JLabel();
        ImageIcon icon3 = new ImageIcon("raichu.jpg");
        icon3 = new ImageIcon(icon3.getImage().getScaledInstance(250, 200, Image.SCALE_SMOOTH));
        OrigPic.setIcon(icon3);
        HrdcrePicPnl.add(OrigPic);
        imagePnl.add("OrigHrdcre", HrdcrePicPnl);

        southPnl.add(southWestPnl);
        southPnl.add(Instructions);
        southPnl.add(imagePnl);
    }

    public ImageIcon[] shuffleImages(ImageIcon[] toBeShuffled) {
        int currIndex = 0;
        for (int i = 0; i < 50; i++) { // Shuffle 50 times
            if (currIndex >= 9) {
                currIndex = 0;
            }
            int random = (int) (Math.random() * toBeShuffled.length);
            ImageIcon currImage = toBeShuffled[currIndex];
            ImageIcon randomImage = toBeShuffled[random];
            toBeShuffled[currIndex] = randomImage;
            toBeShuffled[random] = currImage;
            currIndex++;
        }
        return toBeShuffled;
    }

    public void setEnablePuzzleBtn(boolean status) {
        for (int i = 0; i < noobArr.length; i++) {
            noobArr[i].setEnabled(status);
        }
        for (int i = 0; i < noobGameArr.length; i++) {
            noobGameArr[i].setEnabled(status);

        }
        
        for (int i = 0; i < expArr.length; i++) {
            expArr[i].setEnabled(status);
        }
        for (int i = 0; i < expGameArr.length; i++) {
            expGameArr[i].setEnabled(status);

        }
        
        for (int i = 0; i < HrdcreArr.length; i++) {
            HrdcreArr[i].setEnabled(status);
        }
        for (int i = 0; i < HrdcreGameArr.length; i++) {
            HrdcreGameArr[i].setEnabled(status);

        }
    }

    public GameFrame() {
        init();
        initNorthPnl();
        initCenterPnl();
        initSouthPnl();
        setEnablePuzzleBtn(false);
        resetBtn.setEnabled(false);
        noobBtn.setEnabled(false);

        setTitle("Pokemon Puzzle!! ^__^");

        add(northPnl, BorderLayout.NORTH);
        add(centerPnl, BorderLayout.CENTER);
        add(southPnl, BorderLayout.SOUTH);
    }

    public void actionPerformed(ActionEvent e) {

        String getName = nameTxt.getText();
        
        // For noob difficulty
        for (int i = 0; i < noobArr.length; i++) {
            if (e.getSource() == noobArr[i]) {
                if (buttonSelected == 0) {
                    selectedImg = (ImageIcon) noobArr[i].getIcon();
                    selectedButton = noobArr[i];
                    noobArr[i].setEnabled(true);
                    buttonSelected = 1;
                    break;
                } else {
                    return;
                }
            }
        }
        for (int i = 0; i < noobGameArr.length; i++) {
            if (e.getSource() == noobGameArr[i]) {
                if (buttonSelected == 1) {
                    movecount++;
                    int num = Integer.parseInt(selectedImg.getDescription());
                    if (num == i) {
                        noobGameArr[i].setIcon(selectedImg);
                        selectedButton.setEnabled(false);
                        instructionTxtA.append("Nice! Keep going!\n\n");
                        completebutton++;
                        if (completebutton == noobGameArr.length) {
                            JOptionPane.showMessageDialog(null, "Congratulations! You have solved the puzzle in " + movecount + " moves!");
                            setEnablePuzzleBtn(false);
                            startBtn.setEnabled(true);
                            resetBtn.setEnabled(false);
                            histBtn.setEnabled(true);
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Wrong! Try again!");
                        instructionTxtA.append("Wrong! Try again!\n\n");
                    }
                }
                buttonSelected = 0;
            }
        }
        
        // For experienced difficulty
        for (int i = 0; i < expArr.length; i++) {
            if (e.getSource() == expArr[i]) {
                if (buttonSelected == 0) {
                    selectedImg = (ImageIcon) expArr[i].getIcon();
                    selectedButton = expArr[i];
                    expArr[i].setEnabled(true);
                    buttonSelected = 1;
                    break;
                } else {
                    return;
                }
            }
        }
        for (int i = 0; i < expGameArr.length; i++) {
            if (e.getSource() == expGameArr[i]) {
                if (buttonSelected == 1) {
                    movecount++;
                    int num = Integer.parseInt(selectedImg.getDescription());
                    if (num == i) {
                        expGameArr[i].setIcon(selectedImg);
                        selectedButton.setEnabled(false);
                        instructionTxtA.append("Nice! Keep going!\n\n");
                        completebutton++;
                        if (completebutton == expGameArr.length) {
                            JOptionPane.showMessageDialog(null, "Congratulations! You have solved the puzzle in " + movecount + " moves!");
                            setEnablePuzzleBtn(false);
                            startBtn.setEnabled(true);
                            resetBtn.setEnabled(false);
                            histBtn.setEnabled(true);
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Wrong! Try again!");
                        instructionTxtA.append("Wrong! Try again!\n\n");
                    }
                }
                buttonSelected = 0;
            }
        }
        
        // For hardcore difficulty
        for (int i = 0; i < HrdcreArr.length; i++) {
            if (e.getSource() == HrdcreArr[i]) {
                if (buttonSelected == 0) {
                    selectedImg = (ImageIcon) HrdcreArr[i].getIcon();
                    selectedButton = HrdcreArr[i];
                    HrdcreArr[i].setEnabled(true);
                    buttonSelected = 1;
                    break;
                } else {
                    return;
                }
            }
        }
        for (int i = 0; i < HrdcreGameArr.length; i++) {
            if (e.getSource() == HrdcreGameArr[i]) {
                if (buttonSelected == 1) {
                    movecount++;
                    int num = Integer.parseInt(selectedImg.getDescription());
                    if (num == i) {
                        HrdcreGameArr[i].setIcon(selectedImg);
                        selectedButton.setEnabled(false);
                        instructionTxtA.append("Nice! Keep going!\n\n");
                        completebutton++;
                        if (completebutton == HrdcreGameArr.length) {
                            JOptionPane.showMessageDialog(null, "Congratulations! You have solved the puzzle in " + movecount + " moves!");
                            setEnablePuzzleBtn(false);
                            startBtn.setEnabled(true);
                            resetBtn.setEnabled(false);
                            histBtn.setEnabled(true);
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Wrong! Try again!");
                        instructionTxtA.append("Wrong! Try again!\n\n");
                    }
                }
                buttonSelected = 0;
            }
        }

        if (e.getSource() == startBtn) {
            if (getName.length() == 0) {
                JOptionPane.showMessageDialog(this, "Please enter your name!");
            } else {
                nameTxt.setEditable(false);
                instructionTxtA.setText("1. Select any puzzle piece. \n"
                        + "2. Place it on any area on the Game Board. \n"
                        + "3. Continue until you have completed the puzzle.\n\n");
                startBtn.setEnabled(false);
                resetBtn.setEnabled(true);
                histBtn.setEnabled(false);
                setEnablePuzzleBtn(true);
            }
        } else if (e.getSource() == resetBtn) {
            ImageIcon[] shuffledArr = shuffleImages(myPicArr);
            for (int i = 0; i < noobArr.length; i++) {
                noobArr[i].setIcon(shuffledArr[i]);
                noobGameArr[i].setIcon(null);
            }
            ImageIcon[] shuffled2Arr = shuffleImages(myPic2Arr);
            for (int i = 0; i < expArr.length; i++) {
                expArr[i].setIcon(shuffled2Arr[i]);
                expGameArr[i].setIcon(null);
            }
            ImageIcon[] shuffled3Arr = shuffleImages(myPic3Arr);
            for (int i = 0; i < HrdcreArr.length; i++) {
                HrdcreArr[i].setIcon(shuffled3Arr[i]);
                HrdcreGameArr[i].setIcon(null);
            }
            instructionTxtA.setText("You have reset the game. \n\n"
                    + "1. Select any puzzle piece. \n"
                    + "2. Place it on any area on the Game Board. \n"
                    + "3. Continue until you have completed the puzzle\n\n");
            resetBtn.setEnabled(true);
            setEnablePuzzleBtn(true);
            completebutton = 0;
            movecount = 0;
        } else if (e.getSource() == exitBtn) {
            setEnablePuzzleBtn(false);
            JOptionPane.showMessageDialog(this, "The game will now exit.");
            System.exit(0);
        } else if (e.getSource() == histBtn) {
            startBtn.setEnabled(true);
            infoStr += ++count + "\t" + getName + "\t" + movecount + "\n";

            JTextArea histTxtA = new JTextArea(infoStr);
            JOptionPane.showMessageDialog(this, histTxtA);
            nameTxt.setEditable(true);
            nameTxt.setText("");
        }

        if (e.getSource() == noobBtn) {
            noobBtn.setEnabled(false);
            expBtn.setEnabled(true);
            HrdcreBtn.setEnabled(true);
            
            selectedPuzzleArr = noobArr;
            selectedBoardArr = noobGameArr;
            CardLayout c1 = (CardLayout)(difficultyPnl.getLayout());
            CardLayout c2 = (CardLayout)(difficultyPnl2.getLayout());
            CardLayout c3 = (CardLayout)(imagePnl.getLayout());
            c1.show(difficultyPnl, "Noob");
            c2.show(difficultyPnl2, "Noob");
            c3.show(imagePnl, "OrigNoob");
            movecount = 0;
            completebutton = 0;
            
        } else if (e.getSource() == expBtn) {
            noobBtn.setEnabled(true);
            expBtn.setEnabled(false);
            HrdcreBtn.setEnabled(true);
            
            selectedPuzzleArr = expArr;
            selectedBoardArr = expGameArr;
            CardLayout c1 = (CardLayout)(difficultyPnl.getLayout());
            CardLayout c2 = (CardLayout)(difficultyPnl2.getLayout());
            CardLayout c3 = (CardLayout)(imagePnl.getLayout());
            c1.show(difficultyPnl,"Experienced");
            c2.show(difficultyPnl2,"Experienced");
            c3.show(imagePnl, "OrigExp");
            movecount = 0;
            completebutton = 0;
            
        } else if (e.getSource() == HrdcreBtn) {
            noobBtn.setEnabled(true);
            expBtn.setEnabled(true);
            HrdcreBtn.setEnabled(false);
            
            selectedPuzzleArr = HrdcreArr;
            selectedBoardArr = HrdcreGameArr;
            CardLayout c1 = (CardLayout)(difficultyPnl.getLayout());
            CardLayout c2 = (CardLayout)(difficultyPnl2.getLayout());
            CardLayout c3 = (CardLayout)(imagePnl.getLayout());
            c1.show(difficultyPnl, "Hardcore");
            c2.show(difficultyPnl2, "Hardcore");
            c3.show(imagePnl, "OrigHrdcre");
            movecount = 0;
            completebutton = 0;
        }
    }
}