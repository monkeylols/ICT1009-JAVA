package JavaProj;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class GameFrameUser extends JFrame {

    public static void main(String[] args) {
        GameFrame PuzzleGame = new GameFrame();

        PuzzleGame.pack();
        PuzzleGame.setResizable(false);
        PuzzleGame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        PuzzleGame.setVisible(true);
    }
}
